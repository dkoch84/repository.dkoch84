"""Watchorder background service.

Kodi runs this once at login and keeps it alive for the session, which is what
keeps the ``PlaybackMonitor`` callbacks (``onAVStarted`` / ``onPlayBackStopped``
/ ``onPlayBackEnded``) wired up.  It also keeps the movie-to-show link map fresh
(``db.refresh_link_map``), so plugin clicks read links from memory instead of
loading the MySQL driver and querying the database themselves.
"""

import json
import time

import xbmc

from db import LINK_MAP_REFRESH_SECONDS, refresh_link_map
from main import ADDON_ID, PlaybackMonitor

# Library notifications that can add, remove or relink a movie or show.
_LIBRARY_EVENTS = {
    "VideoLibrary.OnUpdate",
    "VideoLibrary.OnRemove",
    "VideoLibrary.OnScanFinished",
    "VideoLibrary.OnCleanFinished",
}

# Linking a movie to a show happens in a modal select dialog, and Kodi announces
# nothing when it writes the link.  Refresh shortly after any modal dialog
# closes; the delay lets the database write that follows the dialog land first.
_AFTER_DIALOG_SECONDS = 1


class ServiceMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.links_dirty = True

    def onNotification(self, sender, method, data):
        if method not in _LIBRARY_EVENTS:
            return
        # Episode updates arrive every few seconds during playback (resume
        # points) and never change which movies are linked to a show.
        if method == "VideoLibrary.OnUpdate":
            try:
                if json.loads(data).get("item", {}).get("type") == "episode":
                    return
            except (ValueError, TypeError, AttributeError):
                pass
        self.links_dirty = True


def run():
    xbmc.log("{}: service starting".format(ADDON_ID), xbmc.LOGINFO)
    monitor = ServiceMonitor()
    player = PlaybackMonitor()  # noqa: F841 (Kodi delivers callbacks while it lives)
    xbmc.log("{}: PlaybackMonitor active".format(ADDON_ID), xbmc.LOGINFO)

    next_refresh = 0.0
    dialog_was_open = False
    while not monitor.abortRequested():
        now = time.monotonic()
        dialog_open = xbmc.getCondVisibility("System.HasActiveModalDialog")
        if dialog_was_open and not dialog_open:
            next_refresh = min(next_refresh, now + _AFTER_DIALOG_SECONDS)
        dialog_was_open = dialog_open

        if monitor.links_dirty or now >= next_refresh:
            monitor.links_dirty = False
            refresh_link_map()
            next_refresh = time.monotonic() + LINK_MAP_REFRESH_SECONDS

        if monitor.waitForAbort(1):
            break
    xbmc.log("{}: service exiting".format(ADDON_ID), xbmc.LOGINFO)


if __name__ == "__main__":
    run()

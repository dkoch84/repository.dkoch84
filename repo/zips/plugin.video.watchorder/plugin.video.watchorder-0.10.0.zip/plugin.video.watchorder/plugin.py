"""Plugin entry point.

The addon declares ``reuselanguageinvoker``, so Kodi keeps one Python
interpreter alive between plugin invocations and re-executes only this file on
each click.  Imported modules (and their connections and caches) survive, which
is the point, but it also means nothing may read ``sys.argv`` at import time:
``main.run`` binds each invocation's handle and URL instead.
"""

import sys

import main

main.run(sys.argv)

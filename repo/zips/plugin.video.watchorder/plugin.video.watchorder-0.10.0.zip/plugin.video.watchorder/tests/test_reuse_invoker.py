"""Plugin state across reused invocations.

With reuselanguageinvoker Kodi keeps ``main`` and every module it imported
loaded between clicks, and re-executes only plugin.py.  Each click must still
use its own handle and URL: a handle left over from an earlier click makes Kodi
wait on a directory that never finishes.
"""

from __future__ import annotations

import os
import runpy
import sys


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
BASE = "plugin://plugin.video.watchorder/"


def _fake_library(main, monkeypatch):
    monkeypatch.setattr(main, "ensure_forced_views", lambda: None)
    monkeypatch.setattr(
        main, "jsonrpc",
        lambda method, params=None: {
            "tvshows": [{"title": "Show", "tvshowid": 1, "tag": ["anime"]}],
        },
        raising=False,
    )


def test_each_run_binds_its_own_handle(main, monkeypatch):
    """list_tag_folders reads HANDLE via ``from main import`` inside tv-side
    code, the path that went stale when main read sys.argv at import time."""
    import xbmcplugin

    _fake_library(main, monkeypatch)
    xbmcplugin.endOfDirectory.reset_mock()
    xbmcplugin.addDirectoryItems.reset_mock()

    main.run([BASE, "7", "?action=tv_tags"])
    main.run([BASE, "8", "?action=tv_tags"])

    handles = [c[0][0] for c in xbmcplugin.endOfDirectory.call_args_list]
    assert handles == [7, 8]
    added = [c[0][0] for c in xbmcplugin.addDirectoryItems.call_args_list]
    assert added == [7, 8]


def test_run_binds_base_url_for_built_urls(main, monkeypatch):
    import xbmcplugin

    _fake_library(main, monkeypatch)
    xbmcplugin.addDirectoryItems.reset_mock()

    main.run([BASE, "3", "?action=tv_tags"])

    items = xbmcplugin.addDirectoryItems.call_args[0][1]
    assert items[0][0] == BASE + "?action=root_tv&tag=anime"


def test_root_menu_without_query(main, monkeypatch):
    import xbmcplugin

    monkeypatch.setattr(main, "ensure_forced_views", lambda: None)
    xbmcplugin.addDirectoryItems.reset_mock()

    main.run([BASE, "5", ""])

    handle, items, total = xbmcplugin.addDirectoryItems.call_args[0]
    assert handle == 5
    assert total == len(items) == 4


def test_plugin_py_runs_main_with_current_argv(main, monkeypatch):
    calls = []
    monkeypatch.setattr(main, "run", calls.append)
    argv = [BASE, "11", "?action=root_tv"]
    monkeypatch.setattr(sys, "argv", argv)

    runpy.run_path(os.path.join(ROOT, "plugin.py"))

    assert calls == [argv]


def test_main_py_as_entry_point_still_runs(main, monkeypatch):
    """A Kodi that cached the 0.9.x manifest (library="main.py") runs main.py
    as __main__.  It must still route, through the imported main module."""
    calls = []
    monkeypatch.setattr(main, "run", calls.append)
    argv = [BASE, "12", "?action=root_tv"]
    monkeypatch.setattr(sys, "argv", argv)

    runpy.run_path(os.path.join(ROOT, "main.py"), run_name="__main__")

    assert calls == [argv]

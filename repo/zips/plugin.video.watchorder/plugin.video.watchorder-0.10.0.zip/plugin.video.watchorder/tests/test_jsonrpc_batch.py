"""``main.jsonrpc_batch``: several JSON-RPC calls in one executeJSONRPC round trip."""

from __future__ import annotations

import json


def test_results_follow_call_order(main, monkeypatch):
    import xbmc

    sent = []

    def fake(payload):
        sent.append(json.loads(payload))
        # Out of order, with an error for the middle call.
        return json.dumps([
            {"jsonrpc": "2.0", "id": 2, "result": {"n": 2}},
            {"jsonrpc": "2.0", "id": 0, "result": {"n": 0}},
            {"jsonrpc": "2.0", "id": 1, "error": {"code": -32602}},
        ])

    monkeypatch.setattr(xbmc, "executeJSONRPC", fake)

    results = main.jsonrpc_batch([("A", {"x": 1}), ("B", None), ("C", {"y": 2})])

    assert results == [{"n": 0}, None, {"n": 2}]
    assert len(sent) == 1
    assert [c["method"] for c in sent[0]] == ["A", "B", "C"]
    assert "params" not in sent[0][1]


def test_empty_batch_makes_no_call(main, monkeypatch):
    import xbmc

    def boom(_payload):
        raise AssertionError("executeJSONRPC called for an empty batch")

    monkeypatch.setattr(xbmc, "executeJSONRPC", boom)
    assert main.jsonrpc_batch([]) == []


def test_non_batch_response_yields_none_for_every_call(main, monkeypatch):
    import xbmc

    monkeypatch.setattr(
        xbmc, "executeJSONRPC",
        lambda _payload: json.dumps({"jsonrpc": "2.0", "error": {"code": -32700}}),
    )
    assert main.jsonrpc_batch([("A", None), ("B", None)]) == [None, None]


def test_linked_movie_details_use_one_batch(main, monkeypatch):
    import tv

    batches = []

    def fake_batch(calls):
        batches.append(calls)
        return [
            {"moviedetails": {"movieid": 11, "title": "One"}},
            None,  # movie 12 is gone from the library
            {"moviedetails": {"movieid": 13, "title": "Three"}},
        ]

    monkeypatch.setattr(main, "jsonrpc_batch", fake_batch)

    details = tv._get_movie_details([11, 12, 13])

    assert len(batches) == 1
    assert [p["movieid"] for _, p in batches[0]] == [11, 12, 13]
    assert list(details) == [11, 13]

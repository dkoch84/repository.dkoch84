"""When the service refreshes the movie-to-show link map.

Kodi announces nothing when a movie is linked to a show, so besides library
notifications the service refreshes shortly after any modal dialog closes (the
link is picked in one) and on a timer.
"""

from __future__ import annotations

import importlib
import json
import types

import pytest


@pytest.fixture
def service(main):
    import service as service_module

    importlib.reload(service_module)
    return service_module


def test_episode_updates_do_not_dirty_links(service):
    monitor = service.ServiceMonitor()
    monitor.links_dirty = False

    monitor.onNotification(
        "xbmc", "VideoLibrary.OnUpdate",
        json.dumps({"item": {"type": "episode", "id": 1}, "playcount": 1}),
    )
    assert monitor.links_dirty is False

    monitor.onNotification(
        "xbmc", "VideoLibrary.OnUpdate",
        json.dumps({"item": {"type": "movie", "id": 1}}),
    )
    assert monitor.links_dirty is True


@pytest.mark.parametrize("method, dirty", [
    ("VideoLibrary.OnScanFinished", True),
    ("VideoLibrary.OnCleanFinished", True),
    ("VideoLibrary.OnRemove", True),
    ("Player.OnPlay", False),
    ("GUI.OnScreensaverActivated", False),
])
def test_library_events_dirty_links(service, method, dirty):
    monitor = service.ServiceMonitor()
    monitor.links_dirty = False
    monitor.onNotification("xbmc", method, "{}")
    assert monitor.links_dirty is dirty


def test_refreshes_at_start_after_dialog_close_and_on_timer(service, monkeypatch):
    # (monotonic time, modal dialog open) for each loop tick.
    ticks = [
        (0, False),   # start: refresh
        (1, True),    # link dialog opens
        (2, True),
        (3, False),   # closes: refresh one second later
        (4, False),
        (30, False),
        (63, False),
        (64, False),  # 60s after the last refresh
    ]
    state = {"tick": 0}
    refreshed = []

    class ScriptedMonitor(service.ServiceMonitor):
        def abortRequested(self):
            return state["tick"] >= len(ticks)

        def waitForAbort(self, _seconds):
            state["tick"] += 1
            return False

    monkeypatch.setattr(service, "ServiceMonitor", ScriptedMonitor)
    monkeypatch.setattr(service, "PlaybackMonitor", lambda: None)
    monkeypatch.setattr(
        service, "time",
        types.SimpleNamespace(monotonic=lambda: ticks[state["tick"]][0]),
    )
    monkeypatch.setattr(
        service.xbmc, "getCondVisibility",
        lambda _cond: ticks[state["tick"]][1],
    )
    monkeypatch.setattr(
        service, "refresh_link_map",
        lambda: refreshed.append(ticks[state["tick"]][0]),
    )

    service.run()

    assert refreshed == [0, 4, 64]

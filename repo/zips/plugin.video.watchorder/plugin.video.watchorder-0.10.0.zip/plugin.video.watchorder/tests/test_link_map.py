"""Movie-to-show links: the service-published map and the database fallback.

The plugin reads links from a home-window property the service keeps fresh,
so a click never loads mysql.connector.  When the map is missing or stale the
plugin queries Kodi's video database itself.
"""

from __future__ import annotations

import importlib
import json
import os
import sqlite3
import sys
import time
import types

import pytest


MYSQL = {"host": "db", "port": 3306, "user": "kodi", "password": "kodi"}


@pytest.fixture
def db(main):
    import db as db_module
    import xbmcgui

    importlib.reload(db_module)
    xbmcgui.Window(10000).clearProperty("watchorder.linkmap")
    return db_module


def _no_query(tvshowid=None):
    raise AssertionError("queried the database")


def test_plugin_reads_published_map_without_querying(db, monkeypatch):
    monkeypatch.setattr(
        db, "_query_links", lambda tvshowid=None: [(5, 11), (5, 12), (6, 20)]
    )
    assert db.refresh_link_map() is True

    monkeypatch.setattr(db, "_query_links", _no_query)
    assert db.get_linked_movie_ids(5) == [11, 12]
    assert db.get_linked_movie_ids(6) == [20]
    assert db.get_linked_movie_ids(7) == []


def test_missing_map_falls_back_to_query(db, monkeypatch):
    calls = []

    def fake(tvshowid=None):
        calls.append(tvshowid)
        return [(5, 11)]

    monkeypatch.setattr(db, "_query_links", fake)
    assert db.get_linked_movie_ids(5) == [11]
    assert calls == [5]


def test_stale_map_falls_back_to_query(db, monkeypatch):
    """A map the service stopped refreshing must not be trusted forever."""
    import xbmcgui

    xbmcgui.Window(10000).setProperty(
        "watchorder.linkmap",
        json.dumps({"t": time.time() - db._LINK_MAP_MAX_AGE - 1, "v": {"5": [99]}}),
    )
    monkeypatch.setattr(db, "_query_links", lambda tvshowid=None: [(5, 11)])
    assert db.get_linked_movie_ids(5) == [11]


def test_failed_refresh_keeps_previous_map(db, monkeypatch):
    monkeypatch.setattr(db, "_query_links", lambda tvshowid=None: [(5, 11)])
    assert db.refresh_link_map() is True

    monkeypatch.setattr(db, "_query_links", lambda tvshowid=None: None)
    assert db.refresh_link_map() is False
    assert db.get_linked_movie_ids(5) == [11]


def test_failed_query_without_map_returns_empty(db, monkeypatch):
    monkeypatch.setattr(db, "_query_links", lambda tvshowid=None: None)
    assert db.get_linked_movie_ids(5) == []


# -- MySQL ---------------------------------------------------------------------

@pytest.fixture
def fake_mysql(monkeypatch):
    """Install a fake mysql.connector; record connect kwargs and SQL."""
    connects = []
    executed = []

    class Cursor:
        def __init__(self):
            self._sql = ""

        def execute(self, sql, params=None):
            self._sql = sql
            executed.append(sql)

        def fetchall(self):
            if self._sql.startswith("SHOW DATABASES"):
                return [("MyVideos119",), ("MyVideos131",)]
            return [(5, 11), (6, 20)]

        def close(self):
            pass

    class Connection:
        database = None

        def cursor(self):
            return Cursor()

        def ping(self, **_kwargs):
            pass

        def commit(self):
            pass

    connector = types.ModuleType("mysql.connector")
    connector.connect = lambda **kwargs: connects.append(kwargs) or Connection()
    package = types.ModuleType("mysql")
    package.connector = connector
    monkeypatch.setitem(sys.modules, "mysql", package)
    monkeypatch.setitem(sys.modules, "mysql.connector", connector)
    return connects, executed


def test_mysql_connection_uses_autocommit(db, fake_mysql, monkeypatch):
    """Without autocommit a long-lived connection reads from its first
    snapshot, hiding links added by other Kodi installs."""
    connects, executed = fake_mysql
    monkeypatch.setattr(db, "get_mysql_settings", lambda: MYSQL)

    assert db._query_links() == [(5, 11), (6, 20)]
    assert db._query_links(5) == [(5, 11), (6, 20)]

    assert len(connects) == 1  # the second query reuses the connection
    assert connects[0]["autocommit"] is True
    assert "`MyVideos131`.movielinktvshow" in executed[-1]
    assert "WHERE idShow = 5" in executed[-1]


def test_shared_config_connection_uses_autocommit(db, fake_mysql, monkeypatch):
    connects, _ = fake_mysql
    monkeypatch.setattr(db, "get_mysql_settings", lambda: MYSQL)
    monkeypatch.setattr(db, "_shared_collections_enabled", lambda: True)

    assert db._get_connection() is not None
    assert connects[0]["autocommit"] is True


def test_mysql_failure_does_not_read_local_sqlite(db, monkeypatch):
    """On a MySQL install the local MyVideos file is an old copy."""
    import xbmcvfs

    monkeypatch.setattr(db, "get_mysql_settings", lambda: MYSQL)
    monkeypatch.setattr(db, "_get_video_connection", lambda settings: None)

    def boom(_path):
        raise AssertionError("read the local SQLite database")

    monkeypatch.setattr(xbmcvfs, "listdir", boom, raising=False)
    assert db._query_links(5) is None


def test_mysql_driver_not_loaded_without_mysql_settings(db, monkeypatch, tmp_path):
    import xbmcvfs

    monkeypatch.setattr(db, "get_mysql_settings", lambda: None)
    monkeypatch.setattr(db, "_shared_collections_enabled", lambda: True)

    def no_driver(_settings):
        raise AssertionError("loaded the MySQL driver")

    monkeypatch.setattr(db, "_connect", no_driver)
    monkeypatch.setattr(xbmcvfs, "translatePath", lambda _p: str(tmp_path) + "/")
    monkeypatch.setattr(
        xbmcvfs, "listdir", lambda d: ([], os.listdir(d)), raising=False
    )

    assert db._get_connection() is None
    assert db._query_links(5) == []  # no MyVideos file at all


def test_sqlite_query(db, monkeypatch, tmp_path):
    import xbmcvfs

    path = tmp_path / "MyVideos131.db"
    conn = sqlite3.connect(str(path))
    conn.execute("CREATE TABLE movielinktvshow (idMovie integer, IdShow integer)")
    conn.executemany(
        "INSERT INTO movielinktvshow (idMovie, idShow) VALUES (?, ?)",
        [(12, 5), (11, 5), (20, 6)],
    )
    conn.commit()
    conn.close()
    (tmp_path / "MyVideos119.db").write_bytes(b"")  # older, must be ignored

    monkeypatch.setattr(db, "get_mysql_settings", lambda: None)
    monkeypatch.setattr(xbmcvfs, "translatePath", lambda _p: str(tmp_path) + "/")
    monkeypatch.setattr(
        xbmcvfs, "listdir", lambda d: ([], os.listdir(d)), raising=False
    )

    assert db._query_links() == [(5, 11), (5, 12), (6, 20)]
    assert db._query_links(5) == [(5, 11), (5, 12)]

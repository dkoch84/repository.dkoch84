import json
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
# Per-invocation plugin state, bound by run().  With reuselanguageinvoker Kodi
# keeps this module loaded between clicks, so reading sys.argv at import time
# would hand every later click the first click's handle.  The background
# service imports this module too and never calls run(), so it keeps -1.
HANDLE = -1
BASE_URL = ""

CONFIG_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/{}/".format(ADDON_ID)
)
CONFIG_PATH = CONFIG_DIR + "collections.json"


def build_url(params):
    return "{}?{}".format(BASE_URL, urlencode(params))


def jsonrpc(method, params=None):
    request = {"jsonrpc": "2.0", "method": method, "id": 1}
    if params:
        request["params"] = params
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        return response.get("result")
    except Exception as e:
        xbmc.log("{}: JSON-RPC error: {}".format(ADDON_ID, e), xbmc.LOGERROR)
        return None


def jsonrpc_batch(calls):
    """Run several JSON-RPC calls in one executeJSONRPC round trip.

    ``calls`` is a list of ``(method, params)`` tuples.  Returns their results
    in the same order, with None in place of any call that failed.
    """
    if not calls:
        return []
    request = []
    for idx, (method, params) in enumerate(calls):
        call = {"jsonrpc": "2.0", "method": method, "id": idx}
        if params:
            call["params"] = params
        request.append(call)
    results = [None] * len(calls)
    try:
        responses = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception as e:
        xbmc.log("{}: JSON-RPC batch error: {}".format(ADDON_ID, e), xbmc.LOGERROR)
        return results
    if not isinstance(responses, list):
        return results
    for response in responses:
        idx = response.get("id")
        if isinstance(idx, int) and 0 <= idx < len(calls):
            results[idx] = response.get("result")
    return results


# Display-preference settings (flatten tvshows, include specials, select-first-
# unwatched) are read on most navigations but changed very rarely.  Cache them
# briefly in the shared window-property store so a browsing session doesn't
# repeat the lookup on every folder.  The TTL is short so a genuine settings
# change still takes effect within a few seconds.
_SETTING_CACHE_TTL = 30


def get_kodi_setting(setting_id):
    from collections_mod import _cache_get, _cache_set

    cache_key = "setting." + setting_id
    cached = _cache_get(cache_key, ttl=_SETTING_CACHE_TTL)
    if cached is not None:
        return cached

    result = jsonrpc("Settings.GetSettingValue", {"setting": setting_id})
    if result and "value" in result:
        # Only successful reads are cached — never a failed/None lookup, so a
        # transient JSON-RPC error doesn't get pinned for the whole TTL.
        _cache_set(cache_key, result["value"])
        return result["value"]
    return None


def _select_first_unwatched(first_unwatched_index):
    if first_unwatched_index is None or first_unwatched_index < 0:
        return
    setting = get_kodi_setting("videolibrary.tvshowsselectfirstunwatcheditem")
    if not setting or setting == 0:
        return
    # Brief settle so the container has rendered before we move focus.  Kept
    # small to avoid adding latency to every season/episode browse; if the
    # focus occasionally fails to land on slower hardware, raise this value.
    xbmc.sleep(50)
    container_id = xbmc.getInfoLabel("System.CurrentControlID")
    if container_id:
        xbmc.executebuiltin(
            "SetFocus({},{},absolute)".format(container_id, first_unwatched_index)
        )


def watched_menu_item(build_url, media, playcount, **params):
    """Build a 'Mark as Watched/Unwatched' context menu tuple."""
    label = "Set Unwatched" if playcount > 0 else "Set Watched"
    url_params = {"action": "set_watched", "media": media,
                  "playcount": 0 if playcount > 0 else 1}
    url_params.update(params)
    return (label, "RunPlugin({})".format(build_url(url_params)))


def action_set_watched(params):
    """Set watched state for a library item via JSON-RPC."""
    media = params["media"][0]
    playcount = int(params["playcount"][0])

    if media == "episode":
        details = {"episodeid": int(params["id"][0]), "playcount": playcount}
        # Clear resume point when marking as watched
        if playcount > 0:
            details["resume"] = {"position": 0, "total": 0}
        jsonrpc("VideoLibrary.SetEpisodeDetails", details)
    elif media == "movie":
        details = {"movieid": int(params["id"][0]), "playcount": playcount}
        # Clear resume point when marking as watched
        if playcount > 0:
            details["resume"] = {"position": 0, "total": 0}
        jsonrpc("VideoLibrary.SetMovieDetails", details)
    elif media == "season":
        result = jsonrpc("VideoLibrary.GetEpisodes", {
            "tvshowid": int(params["tvshowid"][0]),
            "season": int(params["season"][0]),
            "properties": ["title"],
        })
        for ep in (result or {}).get("episodes", []):
            details = {"episodeid": ep["episodeid"], "playcount": playcount}
            if playcount > 0:
                details["resume"] = {"position": 0, "total": 0}
            jsonrpc("VideoLibrary.SetEpisodeDetails", details)
    elif media == "tvshow":
        result = jsonrpc("VideoLibrary.GetEpisodes", {
            "tvshowid": int(params["tvshowid"][0]),
            "properties": ["title"],
        })
        for ep in (result or {}).get("episodes", []):
            details = {"episodeid": ep["episodeid"], "playcount": playcount}
            if playcount > 0:
                details["resume"] = {"position": 0, "total": 0}
            jsonrpc("VideoLibrary.SetEpisodeDetails", details)

    xbmc.executebuiltin("Container.Refresh")


class PlaybackMonitor(xbmc.Player):
    """Subclass of xbmc.Player so Kodi delivers onAVStarted / onPlayBack* callbacks to us.

    Auto-marks episodes/movies as watched and saves resume points. The class
    used to inherit ``xbmc.Monitor`` — those callbacks never fired because
    Kodi only routes playback events to ``xbmc.Player`` subclasses.
    """

    # Treat playback as effectively complete (watched) if the remaining time is
    # within either of these thresholds. Matches Kodi's own defaults for
    # <ignoresecondsatend> / <ignorepercentatend> in advancedsettings.xml.
    COMPLETE_SECONDS_FROM_END = 180  # last 3 minutes count as watched
    COMPLETE_PERCENT_FROM_END = 0.08  # or last 8% of runtime

    @classmethod
    def _is_effectively_complete(cls, position, duration):
        """Return True if `position` is close enough to `duration` to count as watched."""
        if not duration or duration <= 0 or position <= 0:
            return False
        remaining = max(0, duration - position)
        if remaining <= cls.COMPLETE_SECONDS_FROM_END:
            return True
        if remaining / duration <= cls.COMPLETE_PERCENT_FROM_END:
            return True
        return False

    def __init__(self):
        """Initialize the playback monitor."""
        super().__init__()
        # xbmc.Player has no abort lifecycle; we keep a separate xbmc.Monitor
        # to drive the periodic-save thread's exit condition.
        self._abort = xbmc.Monitor()
        # Back-compat alias so ``self.player.foo`` still works for any tests
        # or callers that haven't been updated.
        self.player = self
        self.current_episodeid = None
        self.current_movieid = None
        # Cached from the periodic-save thread so onPlayBackStopped stays
        # reliable even when getTime()/getTotalTime() return 0 after the
        # player has already been stopped.
        self.last_known_position = 0
        self.last_known_duration = 0
        self.save_interval = 5  # Save resume point every 5 seconds
        # Session-level IDs survive _clear_state() so that onPlayBackEnded can
        # still mark the episode/movie watched even when onPlayBackStopped fires
        # first (as it does in Kodi 19+ on natural completion) and already
        # nulled current_episodeid/current_movieid via _clear_state().
        self._session_episodeid = None
        self._session_movieid = None
        self._start_periodic_save()

    def _capture_current_item(self):
        """Identify the playing item by parsing the plugin URL.

        ``getVideoInfoTag()`` is unreliable for plugin-resolved playback —
        Kodi often hands back an empty tag because the resolved URL is the
        underlying file, not a library item. The plugin URL we built in
        ``play_episode`` / ``play_movie`` carries ``episodeid`` / ``movieid``
        in the query string, so we parse that directly. Falls back to the
        VideoInfoTag for library-initiated playback.
        """
        self.current_episodeid = None
        self.current_movieid = None

        playing_url = ""
        try:
            if not self.player.isPlaying():
                return
            playing_url = self.player.getPlayingFile() or ""
        except Exception:
            playing_url = ""

        if playing_url.startswith("plugin://{}/".format(ADDON_ID)):
            try:
                from urllib.parse import urlparse, parse_qs
                params = parse_qs(urlparse(playing_url).query)
                if "episodeid" in params:
                    self.current_episodeid = int(params["episodeid"][0])
                    self._session_episodeid = self.current_episodeid
                    return
                if "movieid" in params:
                    self.current_movieid = int(params["movieid"][0])
                    self._session_movieid = self.current_movieid
                    return
            except Exception as e:
                xbmc.log("{}: Failed to parse plugin URL '{}': {}".format(
                    ADDON_ID, playing_url, e), xbmc.LOGWARNING)

        # Fallback: library-initiated playback exposes a real VideoInfoTag.
        try:
            tag = self.player.getVideoInfoTag()
            media_type = tag.getMediaType()
            db_id = tag.getDbId()
        except Exception:
            return
        if not db_id or db_id <= 0:
            return
        if media_type == "episode":
            self.current_episodeid = db_id
            self._session_episodeid = db_id
        elif media_type == "movie":
            self.current_movieid = db_id
            self._session_movieid = db_id

    def _clear_state(self):
        self.current_episodeid = None
        self.current_movieid = None
        self.last_known_position = 0
        self.last_known_duration = 0
        # _session_episodeid / _session_movieid are intentionally NOT cleared
        # here — they persist until the next onAVStarted so that onPlayBackEnded
        # can still mark the item watched even when onPlayBackStopped fired first.

    def _clear_session(self):
        """Reset per-playback session IDs.  Call from onAVStarted and after
        onPlayBackEnded has used the IDs to mark the item watched."""
        self._session_episodeid = None
        self._session_movieid = None

    # NOTE: there is intentionally no post-playback Container.Refresh here.
    # Kodi already reloads the directory when returning from fullscreen video,
    # and an explicit Container.Refresh from the service collides with that
    # in-progress reload ("CGUIMediaWindow::OnMessage - updating in progress"),
    # which intermittently left a blank list.  The watched overlay / resume bar
    # update on Kodi's own return-from-playback reload (or on next navigation);
    # we do not force it.

    def onAVStarted(self):
        """Called when audio/video playback starts. Prime the cache."""
        # New content is starting — discard any leftover session IDs from the
        # previous item so they cannot bleed into this playback.
        self._clear_session()
        self._capture_current_item()
        try:
            if self.player.isPlaying():
                self.last_known_duration = self.player.getTotalTime()
                self.last_known_position = self.player.getTime()
        except Exception:
            pass
        xbmc.log("{}: onAVStarted episodeid={} movieid={} duration={}".format(
            ADDON_ID, self.current_episodeid, self.current_movieid,
            self.last_known_duration), xbmc.LOGINFO)

    def onPlayBackEnded(self):
        """Called when playback ends naturally.

        In Kodi 19+ this fires *before* ``onPlayBackStopped`` on natural
        completion.  In some builds the order is reversed; we therefore use
        ``_session_episodeid`` / ``_session_movieid`` as a fallback so we can
        mark the item watched even when ``onPlayBackStopped`` already ran and
        cleared ``current_episodeid`` / ``current_movieid`` via
        ``_clear_state()``.
        """
        episodeid = (self.current_episodeid
                     if self.current_episodeid is not None
                     else self._session_episodeid)
        movieid = (self.current_movieid
                   if self.current_movieid is not None
                   else self._session_movieid)

        if episodeid is not None:
            try:
                jsonrpc("VideoLibrary.SetEpisodeDetails", {
                    "episodeid": episodeid,
                    "playcount": 1,
                    "resume": {"position": 0, "total": 0}
                })
                xbmc.log("{}:Auto-marked episode {} as watched".format(
                    ADDON_ID, episodeid), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log("{}:Failed to mark episode as watched: {}".format(
                    ADDON_ID, e), xbmc.LOGERROR)
        elif movieid is not None:
            try:
                jsonrpc("VideoLibrary.SetMovieDetails", {
                    "movieid": movieid,
                    "playcount": 1,
                    "resume": {"position": 0, "total": 0}
                })
                xbmc.log("{}:Auto-marked movie {} as watched".format(
                    ADDON_ID, movieid), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log("{}:Failed to mark movie as watched: {}".format(
                    ADDON_ID, e), xbmc.LOGERROR)

        self._clear_state()
        self._clear_session()

    def onPlayBackStopped(self):
        """Called when playback is stopped."""
        position = 0
        duration = 0
        try:
            position = self.player.getTime()
            duration = self.player.getTotalTime()
        except Exception as e:
            xbmc.log("{}:Error reading playback position on stop: {}".format(ADDON_ID, e), xbmc.LOGWARNING)

        # Resolve the best available position.
        #
        # On some Kodi builds getTime()/getTotalTime() return 0 once the player
        # has already stopped — fall back to the cache primed by the periodic-
        # save thread.
        #
        # On other builds (including some that fire onPlayBackStopped BEFORE
        # onPlayBackEnded on natural completion) getTime() returns a stale value
        # frozen at the last player-internal tick — which may be the position
        # from the periodic-save just *before* the near-end zone (e.g. 1200s
        # on a 23-minute / 1381s episode where 181s > COMPLETE_SECONDS_FROM_END
        # of 180s).  The periodic-save cache is updated every save_interval
        # seconds and reflects the true play position more faithfully, so we
        # take the *maximum* of the two: if the cache is further ahead than
        # the player's reported value, the cache wins.
        if position <= 0:
            position = self.last_known_position
        elif self.last_known_position > position:
            position = self.last_known_position

        if not duration or duration <= 0:
            duration = self.last_known_duration

        try:
            if duration > 0 and position > 0:
                if self._is_effectively_complete(position, duration):
                    watched_percent = (position / duration) * 100
                    if self.current_episodeid is not None:
                        jsonrpc("VideoLibrary.SetEpisodeDetails", {
                            "episodeid": self.current_episodeid,
                            "playcount": 1,
                            "resume": {"position": 0, "total": 0}
                        })
                        xbmc.log("{}:Auto-marked episode {} as watched (stopped at {}%)".format(
                            ADDON_ID, self.current_episodeid, int(watched_percent)), xbmc.LOGINFO)
                    elif self.current_movieid is not None:
                        jsonrpc("VideoLibrary.SetMovieDetails", {
                            "movieid": self.current_movieid,
                            "playcount": 1,
                            "resume": {"position": 0, "total": 0}
                        })
                        xbmc.log("{}:Auto-marked movie {} as watched (stopped at {}%)".format(
                            ADDON_ID, self.current_movieid, int(watched_percent)), xbmc.LOGINFO)
                else:
                    self._save_resume_point_with(position, duration)
        except Exception as e:
            xbmc.log("{}:Error handling playback stop: {}".format(ADDON_ID, e), xbmc.LOGWARNING)

        self._clear_state()

    def onPlayBackPaused(self):
        """Called when playback is paused."""
        self._save_resume_point()

    def _save_resume_point(self):
        """Capture the current playback position from the player and persist it."""
        if not self.player.isPlaying():
            return

        try:
            position = self.player.getTime()
            duration = self.player.getTotalTime()
        except Exception as e:
            xbmc.log("{}:Failed to read playback position: {}".format(ADDON_ID, e), xbmc.LOGWARNING)
            return

        # Cache the latest live values so onPlayBackStopped can fall back to
        # them if the player has already gone away by the time it fires.
        if duration and duration > 0:
            self.last_known_duration = duration
        if position and position > 0:
            self.last_known_position = position

        # If onAVStarted hasn't run yet (or fired before metadata was ready),
        # try once more here so the periodic ticks can recover the db id.
        if self.current_episodeid is None and self.current_movieid is None:
            self._capture_current_item()

        self._save_resume_point_with(position, duration)

    def _save_resume_point_with(self, position, duration):
        """Persist a resume point, unless playback is effectively complete."""
        if not duration or duration <= 0 or not position or position <= 10:
            return

        # Treat near-the-end positions as watched elsewhere — never store a
        # resume point that would pop back into the near-end zone.
        if self._is_effectively_complete(position, duration):
            return

        try:
            if self.current_episodeid is not None:
                jsonrpc("VideoLibrary.SetEpisodeDetails", {
                    "episodeid": self.current_episodeid,
                    "resume": {"position": position, "total": duration}
                })
            elif self.current_movieid is not None:
                jsonrpc("VideoLibrary.SetMovieDetails", {
                    "movieid": self.current_movieid,
                    "resume": {"position": position, "total": duration}
                })
        except Exception as e:
            xbmc.log("{}:Failed to save resume point: {}".format(ADDON_ID, e), xbmc.LOGWARNING)

    def _start_periodic_save(self):
        """Start periodic saving of resume point during playback."""
        import threading

        def periodic_save():
            while not self._abort.abortRequested():
                if self._abort.waitForAbort(self.save_interval):
                    break
                if self.isPlaying():
                    self._save_resume_point()

        save_thread = threading.Thread(target=periodic_save, daemon=True)
        save_thread.start()


_forced_views_checked = False


def ensure_forced_views():
    global _forced_views_checked
    if _forced_views_checked:
        return
    _forced_views_checked = True
    seasons_view = xbmc.getInfoLabel('Skin.String(Skin.ForcedView.seasons)')
    episodes_view = xbmc.getInfoLabel('Skin.String(Skin.ForcedView.episodes)')
    if not seasons_view:
        name = xbmc.getInfoLabel('$LOCALIZE[538]')  # "Big icons"
        if name:
            xbmc.executebuiltin(
                'Skin.SetString(Skin.ForcedView.seasons,{})'.format(name)
            )
    if not episodes_view:
        name = xbmc.getInfoLabel('$LOCALIZE[31289]')  # "Landscape"
        if name:
            xbmc.executebuiltin(
                'Skin.SetString(Skin.ForcedView.episodes,{})'.format(name)
            )
    tvshows_view = xbmc.getInfoLabel('Skin.String(Skin.ForcedView.tvshows)')
    if not tvshows_view:
        name = xbmc.getInfoLabel('$LOCALIZE[31286]')  # "PosterInfo"
        if name:
            xbmc.executebuiltin(
                'Skin.SetString(Skin.ForcedView.tvshows,{})'.format(name)
            )
    movies_view = xbmc.getInfoLabel('Skin.String(Skin.ForcedView.movies)')
    if not movies_view:
        name = xbmc.getInfoLabel('$LOCALIZE[31286]')  # "PosterInfo"
        if name:
            xbmc.executebuiltin(
                'Skin.SetString(Skin.ForcedView.movies,{})'.format(name)
            )


def root_menu():
    """Root directory: TV Shows and Movies."""
    xbmcplugin.setContent(HANDLE, "files")

    entries = [
        ("TV Shows", "DefaultTVShows.png", "root_tv"),
        ("Movies", "DefaultMovies.png", "root_movies"),
        ("TV Shows by Tag", "DefaultTags.png", "tv_tags"),
        ("Movies by Tag", "DefaultTags.png", "movie_tags"),
    ]
    items = []
    for label, icon, action in entries:
        li = xbmcgui.ListItem(label, offscreen=True)
        li.setArt({"icon": icon, "thumb": icon})
        items.append((build_url({"action": action}), li, True))
    xbmcplugin.addDirectoryItems(HANDLE, items, len(items))

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def run(argv):
    """Plugin entry point: bind this invocation's handle and URL, then route."""
    global HANDLE, BASE_URL
    BASE_URL = argv[0]
    HANDLE = int(argv[1])
    router(argv[2] if len(argv) > 2 else "")


def router(query=""):
    ensure_forced_views()
    params = parse_qs(query.lstrip("?"))
    action = params.get("action", [None])[0]
    tag = params.get("tag", [None])[0]

    # -- Backward compatibility: bare ?tag= URLs go straight to TV listings --
    if action is None and tag is not None:
        from tv import list_titles
        if tag == "_all":
            list_titles(tag=None)
        else:
            list_titles(tag=tag)
        return

    # -- Root --
    if action is None:
        root_menu()
        return

    collections_only = params.get("collections_only", ["0"])[0] == "1"

    # -- TV routes --
    if action == "root_tv":
        from tv import list_titles
        list_titles(tag=tag, collections_only=collections_only)
    elif action == "tv_tags":
        from collections_mod import list_tag_folders
        list_tag_folders("tv")
    elif action == "collection":
        from collections_mod import list_collection_items
        list_collection_items(int(params["index"][0]), "tv")
    elif action == "seasons":
        from tv import list_seasons
        list_seasons(int(params["tvshowid"][0]))
    elif action == "episodes":
        from tv import list_episodes
        list_episodes(
            int(params["tvshowid"][0]),
            int(params["season"][0]),
        )
    elif action == "play":
        from tv import play_episode
        play_episode(
            int(params["episodeid"][0]),
            params.get("file", [""])[0],
        )
    elif action == "add_to_collection":
        from collections_mod import action_add_to_collection
        action_add_to_collection(params["title"][0], "tv")
    elif action == "edit_collection":
        from collections_mod import action_edit_collection
        action_edit_collection(int(params["index"][0]), "tv")
    elif action == "set_collection_art":
        from collections_mod import action_set_collection_art
        action_set_collection_art(int(params["index"][0]), "tv")
    elif action == "move_in_collection":
        from collections_mod import action_move_in_collection
        action_move_in_collection(
            int(params["index"][0]),
            int(params["pos"][0]),
            params["direction"][0],
            "tv",
        )
    elif action == "remove_from_collection":
        from collections_mod import action_remove_from_collection
        action_remove_from_collection(
            int(params["index"][0]),
            int(params["pos"][0]),
            "tv",
        )
    elif action == "move_show_item":
        from tv import action_move_show_item
        action_move_show_item(
            int(params["tvshowid"][0]),
            int(params["pos"][0]),
            params["direction"][0],
        )
    elif action == "move_linked_to_collection":
        from tv import action_move_linked_to_collection
        action_move_linked_to_collection(
            int(params["movieid"][0]),
            int(params["tvshowid"][0]),
        )
    elif action == "move_linked_to_show":
        from tv import action_move_linked_to_show
        action_move_linked_to_show(
            int(params["index"][0]),
            int(params["pos"][0]),
        )

    # -- Movie routes --
    elif action == "root_movies":
        from movies import list_movies
        list_movies(tag=tag, collections_only=collections_only)
    elif action == "movie_tags":
        from collections_mod import list_tag_folders
        list_tag_folders("movie")
    elif action == "movie_collection":
        from collections_mod import list_collection_items
        list_collection_items(int(params["index"][0]), "movie")
    elif action == "list_movies":
        from movies import list_movies
        list_movies(tag=params.get("tag", [None])[0])
    elif action == "play_movie":
        from movies import play_movie
        play_movie(
            int(params["movieid"][0]),
            params.get("file", [""])[0],
        )
    elif action == "add_to_movie_collection":
        from collections_mod import action_add_to_collection
        action_add_to_collection(params["title"][0], "movie")
    elif action == "edit_movie_collection":
        from collections_mod import action_edit_collection
        action_edit_collection(int(params["index"][0]), "movie")
    elif action == "set_movie_collection_art":
        from collections_mod import action_set_collection_art
        action_set_collection_art(int(params["index"][0]), "movie")
    elif action == "move_in_movie_collection":
        from collections_mod import action_move_in_collection
        action_move_in_collection(
            int(params["index"][0]),
            int(params["pos"][0]),
            params["direction"][0],
            "movie",
        )
    elif action == "remove_from_movie_collection":
        from collections_mod import action_remove_from_collection
        action_remove_from_collection(
            int(params["index"][0]),
            int(params["pos"][0]),
            "movie",
        )

    # -- Watched state --
    elif action == "set_watched":
        action_set_watched(params)

    # -- Migration --
    elif action == "migrate_sets":
        from movies import action_migrate_movie_sets
        action_migrate_movie_sets()


if __name__ == "__main__":
    # A Kodi still holding a pre-0.10 manifest runs this file as the entry
    # point.  Hand off to the imported ``main`` module, the one tv.py and
    # friends read HANDLE from, rather than binding it on this __main__ copy.
    import sys

    import main

    main.run(sys.argv)

"""Shared MySQL storage for watchorder collections config, plus lookups in
Kodi's own video database.

Reads MySQL connection details from Kodi's advancedsettings.xml (videodatabase
section).  Falls back silently when mysql.connector is unavailable, MySQL is not
configured, or the server is unreachable.

Module state lives as long as the interpreter: with reuselanguageinvoker the
plugin keeps it across clicks, and the service keeps it for the whole session.
Connections therefore run with autocommit on.  Without it InnoDB answers every
later SELECT on a long-lived connection from the first one's snapshot, so links
and collections changed by another Kodi install would never show up.
"""

import json
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

_ADDON_ID = "plugin.video.watchorder"

# Module-level caches (kept for the life of the interpreter)
_mysql_settings = None
_mysql_settings_parsed = False
_connection = None
_warned = False

# Video DB connection cache (separate from _connection which is gated on shared_collections)
_video_connection = None
_video_db_name = None

# Movie-to-show links, published by the service as a home-window property so a
# plugin click never has to load mysql.connector or open a connection.  Kodi
# sends no library notification when a movie is linked to a show, so the
# service also refreshes on a timer; a map older than _LINK_MAP_MAX_AGE means
# the service has stopped refreshing, and the plugin queries the database.
LINK_MAP_REFRESH_SECONDS = 60
_LINK_MAP_KEY = "linkmap"
_LINK_MAP_MAX_AGE = 3 * LINK_MAP_REFRESH_SECONDS


def get_mysql_settings():
    """Return dict with host/port/user/pass from advancedsettings.xml, or None."""
    global _mysql_settings, _mysql_settings_parsed
    if _mysql_settings_parsed:
        return _mysql_settings
    _mysql_settings_parsed = True

    path = xbmcvfs.translatePath("special://userdata/advancedsettings.xml")
    try:
        tree = ET.parse(path)
    except Exception:
        return None

    vdb = tree.getroot().find("videodatabase")
    if vdb is None:
        return None

    host = vdb.findtext("host")
    if not host:
        return None

    _mysql_settings = {
        "host": host,
        "port": int(vdb.findtext("port", "3306")),
        "user": vdb.findtext("user", "kodi"),
        "password": vdb.findtext("pass", ""),
    }
    return _mysql_settings


def _connect(settings):
    import mysql.connector  # from script.module.myconnpy

    return mysql.connector.connect(
        host=settings["host"],
        port=settings["port"],
        user=settings["user"],
        password=settings["password"],
        connection_timeout=3,
        autocommit=True,
    )


def _ensure_schema(conn):
    """Create the watchorder database and config table if missing."""
    cur = conn.cursor()
    cur.execute(
        "CREATE DATABASE IF NOT EXISTS `watchorder`"
        " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
    )
    cur.execute("USE `watchorder`")
    cur.execute(
        "CREATE TABLE IF NOT EXISTS `config` ("
        "  id INT NOT NULL DEFAULT 1,"
        "  config_json MEDIUMTEXT NOT NULL,"
        "  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
        "    ON UPDATE CURRENT_TIMESTAMP,"
        "  PRIMARY KEY (id),"
        "  CHECK (id = 1)"
        ") ENGINE=InnoDB"
    )
    conn.commit()
    cur.close()


def _shared_collections_enabled():
    """Check if shared collections setting is enabled."""
    import xbmcaddon
    try:
        return xbmcaddon.Addon(_ADDON_ID).getSetting("shared_collections") == "true"
    except Exception:
        return False


def _get_connection():
    """Return a MySQL connection, or None if unavailable."""
    global _connection, _warned

    if not _shared_collections_enabled():
        return None

    # Check the settings before importing: loading mysql.connector costs far
    # more than a click can afford, and is wasted when MySQL isn't configured.
    settings = get_mysql_settings()
    if not settings:
        return None

    # Reuse cached connection if still alive
    if _connection is not None:
        try:
            _connection.ping(reconnect=True, attempts=1, delay=0)
            _connection.database = "watchorder"
            return _connection
        except Exception:
            _connection = None

    try:
        _connection = _connect(settings)
        _ensure_schema(_connection)
        _connection.database = "watchorder"
        return _connection
    except ImportError:
        return None
    except Exception as e:
        if not _warned:
            _warned = True
            xbmc.log(
                "{}: MySQL unavailable, using local JSON: {}".format(_ADDON_ID, e),
                xbmc.LOGWARNING,
            )
        _connection = None
        return None


def db_load_config():
    """Load config dict from MySQL, or return None on any failure."""
    conn = _get_connection()
    if conn is None:
        return None
    try:
        cur = conn.cursor()
        cur.execute("SELECT config_json FROM config WHERE id = 1")
        row = cur.fetchone()
        cur.close()
        if row is None:
            return None
        return json.loads(row[0])
    except Exception as e:
        xbmc.log(
            "{}: MySQL read failed: {}".format(_ADDON_ID, e),
            xbmc.LOGWARNING,
        )
        return None


def _get_video_connection(settings):
    """Return a cached MySQL connection for Kodi's video DB, or None."""
    global _video_connection

    if _video_connection is not None:
        try:
            _video_connection.ping(reconnect=True, attempts=1, delay=0)
            return _video_connection
        except Exception:
            _video_connection = None

    try:
        _video_connection = _connect(settings)
        return _video_connection
    except ImportError:
        return None
    except Exception as e:
        xbmc.log(
            "{}: video DB connection failed: {}".format(_ADDON_ID, e),
            xbmc.LOGWARNING,
        )
        _video_connection = None
        return None


def _get_video_db_name(conn):
    """Return the latest MyVideos DB name, caching the result."""
    global _video_db_name
    if _video_db_name is not None:
        return _video_db_name
    cur = conn.cursor()
    cur.execute("SHOW DATABASES LIKE 'MyVideos%'")
    dbs = [row[0] for row in cur.fetchall()]
    cur.close()
    if dbs:
        _video_db_name = sorted(dbs)[-1]
    return _video_db_name


def _query_links(tvshowid=None):
    """Return ``[(idShow, idMovie), ...]`` from Kodi's video DB, or None on failure.

    Limited to one show when ``tvshowid`` is given.  When MySQL is configured it
    is the only source: the local SQLite file on such an install is an old copy,
    and reading it would silently publish stale links.
    """
    where = " WHERE idShow = {:d}".format(tvshowid) if tvshowid is not None else ""
    sql = "SELECT idShow, idMovie FROM {}movielinktvshow" + where + " ORDER BY idShow, idMovie"

    settings = get_mysql_settings()
    if settings:
        conn = _get_video_connection(settings)
        if conn is None:
            return None
        try:
            video_db = _get_video_db_name(conn)
            if not video_db:
                return None
            cur = conn.cursor()
            cur.execute(sql.format("`{}`.".format(video_db)))
            rows = [(row[0], row[1]) for row in cur.fetchall()]
            cur.close()
            return rows
        except Exception as e:
            xbmc.log(
                "{}: movie link query failed: {}".format(_ADDON_ID, e),
                xbmc.LOGWARNING,
            )
            return None

    try:
        import sqlite3
        db_dir = xbmcvfs.translatePath("special://database/")
        _, files = xbmcvfs.listdir(db_dir)
        video_dbs = sorted(
            f for f in files
            if f.startswith("MyVideos") and f.endswith(".db")
        )
        if not video_dbs:
            return []
        conn = sqlite3.connect(db_dir + video_dbs[-1])
        try:
            return [(row[0], row[1]) for row in conn.execute(sql.format(""))]
        finally:
            conn.close()
    except Exception as e:
        xbmc.log(
            "{}: movie link query failed: {}".format(_ADDON_ID, e),
            xbmc.LOGWARNING,
        )
        return None


def refresh_link_map():
    """Publish every movie-to-show link for the plugin to read.  Service only.

    Returns False when the database could not be read; the previous map is left
    in place and ages out if the failures continue.
    """
    from collections_mod import _cache_set

    rows = _query_links()
    if rows is None:
        return False
    links = {}
    for tvshowid, movieid in rows:
        links.setdefault(str(tvshowid), []).append(movieid)
    _cache_set(_LINK_MAP_KEY, links)
    return True


def get_linked_movie_ids(tvshowid):
    """Get movie IDs linked to a TV show, in movie ID order."""
    from collections_mod import _cache_get

    links = _cache_get(_LINK_MAP_KEY, ttl=_LINK_MAP_MAX_AGE)
    if links is not None:
        return links.get(str(tvshowid), [])
    return [movieid for _, movieid in _query_links(tvshowid) or []]


def db_save_config(config):
    """Save config dict to MySQL.  Best-effort — failures are logged, not raised."""
    conn = _get_connection()
    if conn is None:
        return
    try:
        blob = json.dumps(config, indent=4)
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO config (id, config_json) VALUES (1, %s)"
            " ON DUPLICATE KEY UPDATE config_json = VALUES(config_json)",
            (blob,),
        )
        conn.commit()
        cur.close()
    except Exception as e:
        xbmc.log(
            "{}: MySQL write failed: {}".format(_ADDON_ID, e),
            xbmc.LOGWARNING,
        )

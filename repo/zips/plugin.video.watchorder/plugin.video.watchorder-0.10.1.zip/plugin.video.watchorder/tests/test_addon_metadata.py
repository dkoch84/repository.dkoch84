"""Sanity tests for ``addon.xml``.

A version that doesn't move means Kodi installs never pick up a release, and
the plugin's speed depends on the entry point and invoker settings below.
"""

from __future__ import annotations

import os
import xml.etree.ElementTree as ET


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
ADDON_XML = os.path.join(ROOT, "addon.xml")


def _parse_addon():
    return ET.parse(ADDON_XML).getroot()


def test_addon_id_is_stable():
    assert _parse_addon().get("id") == "plugin.video.watchorder"


def test_addon_version_bumped_for_reused_invoker():
    version = tuple(int(p) for p in _parse_addon().get("version").split("."))
    assert version >= (0, 10, 0)


def test_plugin_reuses_language_invoker():
    """Keeps the interpreter warm between clicks.  Kodi reads this flag only
    from the metadata extension, so anywhere else it is silently ignored."""
    root = _parse_addon()
    metadata = [
        e for e in root.findall("extension")
        if e.get("point") == "xbmc.addon.metadata"
    ]
    assert len(metadata) == 1
    assert metadata[0].findtext("reuselanguageinvoker") == "true"


def test_plugin_entry_point_is_plugin_py():
    """The entry script is re-executed on every click; it must be the thin
    plugin.py that calls main.run, not main.py itself (which would load a
    second, stale copy of main alongside __main__)."""
    root = _parse_addon()
    sources = [
        e for e in root.findall("extension")
        if e.get("point") == "xbmc.python.pluginsource"
    ]
    assert len(sources) == 1
    assert sources[0].get("library") == "plugin.py"
    assert os.path.isfile(os.path.join(ROOT, "plugin.py"))


def test_service_extension_registered():
    """The PlaybackMonitor only fires if Kodi keeps a service process alive."""
    root = _parse_addon()
    services = [
        e for e in root.findall("extension")
        if e.get("point") == "xbmc.service"
    ]
    assert len(services) == 1
    assert services[0].get("library") == "service.py"
